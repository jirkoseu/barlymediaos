// components/layout/app-sidebar.tsx

"use client";

import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Home, Settings, User, FolderClosed, Search } from "lucide-react";
import Image from "next/image"; // Importujeme komponentu Image z Next.js

const navItems = [
  { label: "Dashboard", icon: Home, href: "/" },
  { label: "Search", icon: Search, href: "/search" },
  { label: "File Browser", icon: FolderClosed, href: "/file-browser" },
  { label: "Torrenty", icon: User, href: "/torrents" },
  { label: "Nastavení", icon: Settings, href: "/settings" },
];

interface AppSidebarProps {
  isCollapsed: boolean;
}

export function AppSidebar({ isCollapsed }: AppSidebarProps) {
  return (
    <TooltipProvider>
      <div
        className={cn(
          "relative min-h-screen bg-background border-r p-3 transition-all duration-300 ease-in-out",
          isCollapsed ? "w-[72px]" : "w-64"
        )}
      >
        <div className="flex flex-col h-full duration-200">
          {/* Sekce pro logo a název aplikace */}
          <div className="mb-8 p-2 flex items-center justify-center"> {/* Centrování loga s textem */}
            {/* Logo */}
            <Image
              src="/images/barlymediaos_logob.svg" // Cesta k vašemu logu
              alt="barlyMediaOS Logo"
              width={48} // Nastavte vhodnou šířku
              height={32} // Nastavte vhodnou výšku
              className={cn(
                "transition-all duration-300",
                isCollapsed ? "mr-0" : "mr-3" // Mezera, když je rozbaleno
              )}
            />
            {/* Text názvu aplikace */}
            {!isCollapsed && ( // Zobrazit text jen když NENÍ sbaleno
              <h2 className="text-lg whitespace-nowrap opacity-100 transition-opacity duration-500 fade-in">
                barlyMediaOS
              </h2>
            )}
          </div>

          {/* Navigace */}
          <nav className="flex flex-col gap-2">
            {navItems.map((item) => (
              <Tooltip key={item.label} delayDuration={0}>
                <TooltipTrigger asChild>
                  <a
                    href={item.href}
                    className={cn(
                      "flex items-center gap-4 p-2 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground", isCollapsed? "w-min ml-1.5" : "",
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className={cn("whitespace-nowrap", isCollapsed && "hidden")}>
                      {item.label}
                    </span>
                  </a>
                </TooltipTrigger>
                {isCollapsed && (
                  <TooltipContent side="right">
                    <p>{item.label}</p>
                  </TooltipContent>
                )}
              </Tooltip>
            ))}
          </nav>
        </div>
      </div>
    </TooltipProvider>
  );
}