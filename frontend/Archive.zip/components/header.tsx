"use client";

import { Button } from "@/components/ui/button";
import { PanelLeftClose, PanelLeftOpen, Power } from "lucide-react";
import { DynamicBreadcrumb } from "@/components/layout/dynbreadcrumb";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import DateTime from "@/components/ui/time";

// Rozhraní pro props, které komponenta přijímá
interface HeaderProps {
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
}

export function Header({ isCollapsed, setIsCollapsed }: HeaderProps) {
  return (
    <header className="sticky justify-between top-0 z-10 flex items-center gap-4 bg-background p-4">
      {/* Tlačítko pro sbalení/rozbalení sidebaru */}
      <div className="flex flex-row items-center gap-4">
      <Button
        variant="outline"
        size="icon"
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        {isCollapsed ? (
          <PanelLeftOpen className="h-5 w-5" />
        ) : (
          <PanelLeftClose className="h-5 w-5" />
        )}
        <span className="sr-only">Toggle Sidebar</span>
      </Button>

      {/* Dynamická drobečková navigace */}
      <DynamicBreadcrumb />
      </div>
      <div className="flex flex-row items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger>
              <Power className="h-4 w-4 cursor-pointer text-neutral-400 dark:hover:text-white hover:bg-neutral-800 transition-all duration-200" />
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>Shutdown</DropdownMenuItem>
              <DropdownMenuItem>Restart</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
      <DateTime />
      </div>
    </header>
  );
}