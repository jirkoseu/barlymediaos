import React from "react";
import LoadingAnimation from "@/components/layout/loading-anim";

export default function Settings() {
  return (
    <LoadingAnimation />
  );
}