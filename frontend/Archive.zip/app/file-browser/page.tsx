"use client";
import { TARGET_URL } from "@/app/layout";
import React, { useState, useEffect } from "react";
import {
  ArrowLeft, ArrowRight, ArrowUp, Monitor, FolderPlus, Upload, RefreshCcw,
  Copy, Scissors, Trash, Edit, List, Grid, Folder, File, FileText,
  Presentation, Film, Archive, Settings, Image as ImageIcon, Music
} from "lucide-react";

// Shadcn UI Importy
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";

// Typy
interface FileItem {
  id: string;
  name: string;
  path: string;
  date: string;
  type: string;
  size: string;
  iconType: string;
  isDir: boolean;
}

const API_URL = `http://${TARGET_URL}`;

export default function FileManager() {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [currentPath, setCurrentPath] = useState<string>("");
  const [parentPath, setParentPath] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  // Načtení souborů
  const fetchFiles = async (path: string = "") => {
    setIsLoading(true);
    try {
      const encodedPath = encodeURIComponent(path);
      const res = await fetch(`${API_URL}/api/files?path=${encodedPath}`);
      const data = await res.json();
      
      if (data.files) {
        setFiles(data.files);
        setCurrentPath(data.path);
        setParentPath(data.parent);
      }
    } catch (error) {
      console.error("Failed to fetch files:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  const handleNavigate = (path: string) => {
    fetchFiles(path);
  };

  const handleUp = () => {
    if (parentPath && parentPath !== currentPath) {
      fetchFiles(parentPath);
    }
  };

  const renderIcon = (type: string) => {
    switch (type) {
      case "folder": return <Folder className="w-5 h-5 text-yellow-400 fill-yellow-400/20" />;
      case "pdf": return <File className="w-5 h-5 text-red-500" />;
      case "word": return <FileText className="w-5 h-5 text-blue-500" />;
      case "video": return <Film className="w-5 h-5 text-purple-500" />;
      case "image": return <ImageIcon className="w-5 h-5 text-blue-400" />;
      case "audio": return <Music className="w-5 h-5 text-pink-500" />;
      case "zip": return <Archive className="w-5 h-5 text-orange-400" />;
      case "exe": return <Settings className="w-5 h-5 text-green-500" />;
      case "txt": return <FileText className="w-5 h-5 text-gray-400" />;
      default: return <File className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
      
      {/* --- Top Navigation Bar --- */}
      <div className="flex items-center justify-between gap-2 bg-neutral-100 dark:bg-neutral-900 p-2 rounded-lg border border-neutral-200 dark:border-neutral-700">
        <div className="flex items-center gap-1 w-full">
          {/* Navigation Buttons */}
          <div className="flex items-center gap-1">
            <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleUp} 
                disabled={!parentPath || parentPath === currentPath}
                title="Back"
                className="h-8 w-8 hover:bg-neutral-300 dark:hover:bg-neutral-700"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            
            <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleUp}
                title="Up Level"
                className="h-8 w-8 hover:bg-neutral-300 dark:hover:bg-neutral-700"
            >
              <ArrowUp className="h-4 w-4" />
            </Button>
          </div>
          
          <Separator orientation="vertical" className="h-6 mx-1 bg-neutral-400 dark:bg-neutral-600" />

          {/* Path Bar */}
          <div className="flex-1 flex items-center relative">
            <div className="absolute left-3 flex items-center pointer-events-none">
                <Monitor className="h-4 w-4 text-neutral-500" />
            </div>
            <Input 
                readOnly
                value={currentPath || "Loading..."}
                className="pl-9 h-9 bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 cursor-default focus-visible:ring-0"
            />
          </div>
        </div>

        <div className="flex items-center gap-1 ml-2">
           <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => fetchFiles(currentPath)}
            title="Refresh"
            className="h-8 w-8 hover:bg-neutral-300 dark:hover:bg-neutral-700"
           >
            <RefreshCcw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
           </Button>
        </div>
      </div>

      {/* --- Toolbar --- */}
      <div className="flex items-center gap-2 p-1 overflow-x-auto">
        <div className="flex items-center gap-1">
            <Button variant="secondary" size="sm" className="h-8 gap-2 text-xs bg-neutral-50 dark:bg-neutral-900 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-900 dark:text-neutral-100 border border-neutral-200 dark:border-neutral-700">
                <Copy className="h-3.5 w-3.5" /> Copy
            </Button>
            <Button variant="secondary" size="sm" className="h-8 gap-2 text-xs bg-neutral-50 dark:bg-neutral-900 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-900 dark:text-neutral-100 border border-neutral-200 dark:border-neutral-700">
                <Trash className="h-3.5 w-3.5" /> Delete
            </Button>
            <Button variant="secondary" size="sm" className="h-8 gap-2 text-xs bg-neutral-50 dark:bg-neutral-900 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-900 dark:text-neutral-100 border border-neutral-200 dark:border-neutral-700">
                <Edit className="h-3.5 w-3.5" /> Rename
            </Button>
        </div>
        
        <div className="flex-1" />
        
        <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-900 p-0.5 rounded-md border border-neutral-200 dark:border-neutral-700">
            <Button variant="ghost" size="icon" className="h-7 w-7 rounded-sm hover:bg-neutral-300 dark:hover:bg-neutral-700 shadow-none">
                <List className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7 rounded-sm hover:bg-neutral-300 dark:hover:bg-neutral-700 shadow-none">
                <Grid className="h-4 w-4" />
            </Button>
        </div>
      </div>

      {/* --- File List (Table) --- */}
      <div className="flex-1 border border-neutral-200 dark:border-neutral-800 rounded-md bg-white dark:bg-neutral-950 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-auto">
            <Table>
            <TableHeader className="bg-neutral-100 dark:bg-neutral-900 sticky top-0 z-10">
                <TableRow className="hover:bg-neutral-100 dark:hover:bg-neutral-900 border-neutral-200 dark:border-neutral-700">
                <TableHead className="w-[40%] text-neutral-600 dark:text-neutral-400">Name</TableHead>
                <TableHead className="text-neutral-600 dark:text-neutral-400">Date modified</TableHead>
                <TableHead className="text-neutral-600 dark:text-neutral-400">Type</TableHead>
                <TableHead className="text-right text-neutral-600 dark:text-neutral-400">Size</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {files.length === 0 && !isLoading ? (
                    <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center text-neutral-500">
                            Folder is empty or access denied.
                        </TableCell>
                    </TableRow>
                ) : (
                    files.map((file) => (
                    <TableRow
                        key={file.id}
                        onClick={() => file.isDir && handleNavigate(file.path)}
                        className={`
                            cursor-pointer transition-colors border-neutral-200 dark:border-neutral-800
                            hover:bg-neutral-50 dark:hover:bg-neutral-900
                            ${file.isDir ? 'font-medium' : ''}
                        `}
                    >
                        <TableCell className="py-2">
                            <div className="flex items-center gap-2">
                                {renderIcon(file.iconType)}
                                <span className="truncate max-w-[300px] text-neutral-900 dark:text-neutral-200">{file.name}</span>
                            </div>
                        </TableCell>
                        <TableCell className="py-2 text-xs text-neutral-500 whitespace-nowrap">{file.date}</TableCell>
                        <TableCell className="py-2 text-xs text-neutral-500">{file.type}</TableCell>
                        <TableCell className="py-2 text-xs font-mono text-right text-neutral-500">{file.size}</TableCell>
                    </TableRow>
                    ))
                )}
            </TableBody>
            </Table>
        </div>
      </div>

      {/* --- Status Bar --- */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs text-neutral-600 dark:text-neutral-400">
        <div className="flex items-center gap-3">
            <span>{files.length} items</span>
            <Separator orientation="vertical" className="h-3 bg-neutral-400 dark:bg-neutral-600" />
            <span className="truncate max-w-[400px]">{currentPath}</span>
        </div>
        <div className="flex flex-row gap-2 items-center justify-center">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>Ready</span>
        </div>
      </div>
    </div>
  );
}