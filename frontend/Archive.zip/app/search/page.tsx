"use client";
import { TARGET_URL } from "@/app/layout";
import React, { useState } from "react";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupInput,
} from "@/components/ui/input-group";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { SearchIcon, Download } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import Image from "next/image";
import { Button } from "@/components/ui/button";

import { MovieCard } from "@/components/layout/movie-card"; 
import { SearchResultItem } from "@/lib/types";
import LoadingAnimation from "@/components/layout/loading-anim";
import { link } from "node:fs/promises";
import { toast } from "sonner"

// Typy zpráv ze streamu (necháme lokálně, týkají se jen logiky parseru)
type StreamMessage = 
  | { type: 'info' | 'processing' | 'error'; msg?: string; title?: string }
  | { type: 'result'; data: SearchResultItem }
  | { type: 'done' | 'end'; msg?: string };

export default function Search() {
  const [query, setQuery] = useState("");
  const [isSearching, setSearching] = useState(false);
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [statusMessage, setStatusMessage] = useState(""); 
  const [hasSearched, setHasSearched] = useState(false);
  const [isTdownloading, setisTdownloading] = useState(false);
  const [newMagnet, setNewMagnet] = useState<string>('');


  const [selectedMovie, setSelectedMovie] = useState<SearchResultItem | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // 🎨 Barvy tagů pro DIALOG (zde je stále potřebujeme)
  const tagTypeColors = {
    year: "dark:bg-blue-800 dark:text-blue-400 text-blue-500 bg-blue-100",
    language: "dark:bg-green-700 dark:text-green-400 text-green-500 bg-green-100",
    quality: "dark:bg-purple-700 dark:text-purple-400 text-purple-500 bg-purple-100",
    other: "dark:bg-gray-700 dark:text-gray-400 text-gray-500 bg-gray-100",
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setSearching(true);
    setResults([]);
    setStatusMessage("Startuji motory...");
    setHasSearched(true);

    try {
      const encodedQuery = encodeURIComponent(query);
      const response = await fetch(`http://${TARGET_URL}/search?query=${encodedQuery}`);
      if (!response.body) throw new Error("ReadableStream not supported.");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || ""; 

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const msg: StreamMessage = JSON.parse(line);
            if (msg.type === "result") {
              setResults((prev) => [...prev, msg.data]);
            } else if (msg.type === "info" || msg.type === "processing") {
              setStatusMessage(msg.msg || msg.title || "Pracuji...");
            } else if (msg.type === "done" || msg.type === "end") {
              setSearching(false);
            }
          } catch (err) { console.error(err); }
        }
      }
    } catch (error) {
      console.error(error);
      setStatusMessage("Chyba serveru.");
    } finally {
      setSearching(false);
    }
  };

  const openDetail = (movie: SearchResultItem) => {
    setSelectedMovie(movie);
    setIsDialogOpen(true);
  };

  const handleAddTorrent = async (link?: string, title?:string) => {
    try {
        await fetch(`http://localhost:8000/api/torrents`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ magnet: link, title: "New Download" }), 
        });
      setisTdownloading(true);
      toast.success(`Stahuji ${title}`, {
        description: `Začalo stahování souboru ${title}`,
        action: {
          label: "Otevřít",
          onClick: () => window.open("torrents"),
        },
      })
    } catch (error) {
        console.error("Failed to add torrent", error);
    }
  };
  
  return (
    <main className="h-full w-full flex flex-col items-center justify-center">
      
      {/* --- SEARCH INPUT --- */}
      <div className={`z-20 flex flex-col items-center justify-center gap-4 fixed transition-all duration-500 w-full max-w-2xl ${isSearching || hasSearched ? "top-6" : "top-100"}`}>
        <InputGroup className={`z-10 w-full transition-all duration-300 shadow-lg ${isSearching ? "opacity-90" : ""}`}>
          <InputGroupInput
            placeholder={`${isSearching ? {statusMessage} : "Hledej filmy a seriály..." }`}
            className="text-lg py-6"
            value={query}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            onChange={(e) => setQuery(e.target.value)}
            disabled={isSearching} />
          <InputGroupAddon>
            {isSearching ? <Spinner className="h-6 w-6 text-neutral-400" /> : <SearchIcon className="text-neutral-400" />}
          </InputGroupAddon>
          <InputGroupAddon align="inline-end">
            <InputGroupButton disabled={isSearching} onClick={() => handleSearch()}>Hledat</InputGroupButton>
          </InputGroupAddon>
        </InputGroup>
        <div className={`z-0 text-sm dark:bg-neutral-800 p-1 px-3 rounded-2xl dark:border-neutral-700 border text-neutral-500 transition-all duration-500 opacity-0 ${isSearching ? "opacity-100" : "-mt-10 opacity-0"}`}>
          <span>{statusMessage}</span>
        </div>
      </div>
      {/* --- VÝSLEDKY --- */}
      <div className={`w-full flex flex-wrap justify-center gap-6 transition-all duration-500 ${isSearching ? "mt-6" : ""} `}>
        {!isSearching && hasSearched && results.length === 0 && (
           <div className="text-neutral-400 text-lg mt-10">Nic jsme nenašli.</div>
        )}
        
        {results.map((item) => (
          <MovieCard 
            key={item.url} 
            data={item} 
            onClick={openDetail} 
          />
        ))}
      </div>
      {isSearching && <LoadingAnimation />} {/* Prostor pro stavovou zprávu */}
      {/* --- DIALOG (Zatím necháme zde) --- */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="w-full sm:max-w-4xl h-2/3 p-0 overflow-hidden flex flex-col sm:flex-row bg-white dark:bg-neutral-950">
            {selectedMovie && (
            <>
              <div className="relative w-full sm:w-2/5 h-64 sm:h-auto bg-black">
                 {selectedMovie.image ? (
                    <Image src={selectedMovie.image} alt={selectedMovie.title} fill className="object-contain sm:object-cover" />
                 ) : (
                     <div className="flex h-full items-center justify-center text-white">Bez náhledu</div>
                 )}
              </div>
              <div className="flex flex-col p-6 w-full sm:w-3/5 gap-4">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-left leading-tight">{selectedMovie.title}</DialogTitle>
                  <div className="flex flex-row flex-wrap gap-2 mt-3">
                    <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300">{selectedMovie.size}</Badge>
                    {selectedMovie.tags.map((tag, idx) => (
                         <Badge key={idx} className={tagTypeColors[tag.type as keyof typeof tagTypeColors]}>{tag.value}</Badge>
                    ))}
                  </div>
                </DialogHeader>
                <DialogDescription className="text-neutral-600 dark:text-neutral-300 text-base mt-2">
                  {/* Změna <p> na <span> s display: block (nebo jen prostý text, pokud nepotřebuješ stylovat) */}
                  <span>Soubor je připraven ke stažení.</span>
                  
                  {/* Druhý odstavec také změníme na span + block, aby fungoval margin (mt-4) */}
                  <span className="block text-xs text-neutral-400 mt-4 select-all">
                    Zdroj: {selectedMovie.url}
                  </span>
                </DialogDescription>
                <DialogFooter className="mt-auto pt-6 flex gap-2 justify-end">
                  <DialogClose asChild><Button variant="secondary">Zavřít</Button></DialogClose>
                  {!isTdownloading && selectedMovie.download_link ? (
                    <Button className="gap-2" onClick={() => handleAddTorrent(selectedMovie.download_link, selectedMovie.title)}>
                          <Download className="h-4 w-4" /> Stáhnout Torrent
                      </Button>
                  ) : (
                      <Button disabled variant="outline"><Spinner /> Downloading</Button>
                      
                  )}
                </DialogFooter>
              </div>
            </>
            )}
        </DialogContent>
      </Dialog>

    </main>
  );
}