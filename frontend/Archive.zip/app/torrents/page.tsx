'use client';
import { TARGET_URL } from "@/app/layout";
import { useState, useMemo, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  X, 
  Search, 
  Plus, 
  WifiOff
} from 'lucide-react';

// Shadcn UI imports
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// Definice typu pro Torrent (aktualizováno pro reálný backend)
interface Torrent {
  id: number;
  title: string; // Změněno z 'name' na 'title' kvůli backendu
  status: string; // Transmission vrací stringy jako 'downloading', 'seeding' atd.
  progress: number;
  downloadSpeed: string;
  uploadSpeed: string;
  size: string; // Přidáno z backendu
}

const API_URL = `http://${TARGET_URL}`;
const WS_URL = `ws://${TARGET_URL}/ws`;

export default function TorrentsPage() {
  const [activeTab, setActiveTab] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddTorrent, setShowAddTorrent] = useState<boolean>(false);
  const [newMagnet, setNewMagnet] = useState<string>('');
  
  const [torrents, setTorrents] = useState<Torrent[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  // --- WebSocket Connection ---
  useEffect(() => {
    let ws: WebSocket;
    
    const connect = () => {
        ws = new WebSocket(WS_URL);
        ws.onopen = () => setIsConnected(true);
        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                setTorrents(data);
            } catch (e) {
                console.error("Error parsing WS data", e);
            }
        };
        ws.onclose = () => {
            setIsConnected(false);
            // Automatický reconnect po 3 sekundách
            setTimeout(connect, 3000);
        };
    };

    connect();
    return () => { if (ws) ws.close(); };
  }, []);

  // --- API Actions ---
  const handleAddTorrent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMagnet.trim()) return;
    try {
        await fetch(`${API_URL}/api/torrents`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ magnet: newMagnet, title: "New Download" }), 
        });
        setNewMagnet('');
        setShowAddTorrent(false);
    } catch (error) {
        console.error("Failed to add torrent", error);
    }
  };

  const pauseTorrent = async (id: number) => {
    try {
        await fetch(`${API_URL}/api/torrents/${id}/action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'pause' }),
        });
    } catch (error) { console.error("Failed to pause", error); }
  };

  const resumeTorrent = async (id: number) => {
    try {
        await fetch(`${API_URL}/api/torrents/${id}/action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'resume' }),
        });
    } catch (error) { console.error("Failed to resume", error); }
  };

  const removeTorrent = async (id: number) => {
    try {
        await fetch(`${API_URL}/api/torrents/${id}`, { method: 'DELETE' });
    } catch (error) { console.error("Failed to delete", error); }
  };

  // --- Filtering & Logic ---
  const filteredTorrents = useMemo(() => {
    let filtered = torrents;
    const tab = activeTab.toLowerCase();

    if (tab !== 'all') {
      filtered = filtered.filter(t => {
        const s = t.status.toLowerCase();
        if (tab === 'downloading') return s.includes('download');
        if (tab === 'completed') return s.includes('seed') || s.includes('complete');
        if (tab === 'active') return s.includes('download') || s.includes('upload');
        if (tab === 'inactive') return s.includes('pause') || s.includes('stop') || s.includes('error');
        return true;
      });
    }

    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(t => t.title.toLowerCase().includes(query));
    }
    return filtered;
  }, [torrents, activeTab, searchQuery]);

  const getStatusBadgeClass = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('download')) return 'bg-purple-500/15 text-purple-700 dark:text-purple-400 hover:bg-purple-500/25 border-purple-500/20';
    if (s.includes('seed') || s.includes('complete')) return 'bg-green-500/15 text-green-700 dark:text-green-400 hover:bg-green-500/25 border-green-500/20';
    if (s.includes('pause') || s.includes('stop')) return 'bg-orange-500/15 text-orange-700 dark:text-orange-400 hover:bg-orange-500/25 border-orange-500/20';
    if (s.includes('error')) return 'bg-red-500/15 text-red-700 dark:text-red-400 hover:bg-red-500/25 border-red-500/20';
    return 'bg-slate-500/15 text-slate-700 dark:text-slate-400 hover:bg-slate-500/25 border-slate-500/20';
  };

  return (
    <div className="flex flex-col h-full space-y-4 p-4 bg-background text-foreground">
      
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
          <TabsList className="grid w-full grid-cols-2 sm:flex sm:w-auto">
            {['All', 'Downloading', 'Completed', 'Active', 'Inactive'].map((tab) => (
              <TabsTrigger key={tab} value={tab} className="px-4">{tab}</TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2 w-full sm:w-auto">
            {!isConnected && (
                <Badge variant="destructive" className="hidden sm:flex gap-1 items-center animate-pulse">
                    <WifiOff className="h-3 w-3" /> Reconnecting...
                </Badge>
            )}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search torrents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button onClick={() => setShowAddTorrent(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="h-min overflow-auto border-neutral-200 dark:border-neutral-700 rounded-lg border p-2">
          {filteredTorrents.length === 0 ? (
            <div className="flex h-full items-center justify-center text-muted-foreground py-8 italic">
              {isConnected ? "No torrents found." : "Waiting for backend connection..."}
            </div>
          ) : (
            <Table className='rounded-lg'>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[200px]">Progress</TableHead>
                  <TableHead>Download</TableHead>
                  <TableHead>Size</TableHead> {/* Změněno z Upload na Size pro větší přehlednost */}
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTorrents.map((torrent) => (
                  <TableRow key={torrent.id}>
                    <TableCell className="font-medium max-w-[250px] truncate" title={torrent.title}>
                      {torrent.title}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStatusBadgeClass(torrent.status)}>
                        {torrent.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1.5">
                        <span className="text-xs text-muted-foreground">{Math.round(torrent.progress)}%</span>
                        <Progress value={torrent.progress} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground whitespace-nowrap">{torrent.downloadSpeed}</TableCell>
                    <TableCell className="text-muted-foreground">{torrent.size}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        {torrent.status.toLowerCase().includes('download') ? (
                          <Button variant="ghost" size="icon" onClick={() => pauseTorrent(torrent.id)}>
                            <Pause className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button variant="ghost" size="icon" onClick={() => resumeTorrent(torrent.id)}>
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => removeTorrent(torrent.id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>

      {/* Dialog */}
      <Dialog open={showAddTorrent} onOpenChange={setShowAddTorrent}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Torrent</DialogTitle>
            <DialogDescription>Paste sktorrent link or magnet link below.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddTorrent} className="grid gap-4 py-4">
            <Input
              placeholder="https://sktorrent.eu/... nebo magnet:?"
              value={newMagnet}
              onChange={(e) => setNewMagnet(e.target.value)}
              autoFocus
            />
            <DialogFooter>
              <Button type="submit" disabled={!newMagnet.trim()}>Start Download</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}