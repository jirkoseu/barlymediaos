// app/layout.tsx

"use client";

import { useState } from "react";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { AppSidebar } from "@/components/layout/app-sidebar";
import { Header } from "@/components/header"; // Vytvoříme novou komponentu pro hlavičku
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});


export const TARGET_URL = "Jiris-MacBook-Pro.local:8000";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <Toaster />
          <div className="flex min-h-screen">
            <AppSidebar isCollapsed={isCollapsed} />
            <div className="flex flex-col flex-1">
              <Header
                isCollapsed={isCollapsed}
                setIsCollapsed={setIsCollapsed}
              />
              <main className="flex-1 p-8 bg-background fade-in">
                {children}
              </main>
            </div>
          </div>
          
        </ThemeProvider>
      </body>
    </html>
  );
}
