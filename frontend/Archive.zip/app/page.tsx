"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Clapperboard, Tv, Download, Hand as Hdd } from "lucide-react"
import Image from "next/image"
import { Label, PolarRadiusAxis, RadialBar, RadialBarChart } from "recharts"
import { type ChartConfig, ChartContainer } from "@/components/ui/chart"

const chartData = [{ usage: 30, fill: "hsl(var(--chart-1))" }]

const chartConfig = {
  usage: {
    label: "Usage",
  },
} satisfies ChartConfig

const recentMovies = [
  {
    id: 1,
    title: "Dune: Part Two",
    year: "2024",
    poster: "/dune-part-two-poster.png",
  },
  {
    id: 2,
    title: "Oppenheimer",
    year: "2023",
    poster: "/images/posters/oppenheimer-poster.png",
  },
  {
    id: 3,
    title: "The Batman",
    year: "2022",
    poster: "/images/posters/the-batman-poster.png",
  },
  {
    id: 4,
    title: "Spider-Man: No Way Home",
    year: "2021",
    poster: "/spider-man-no-way-home-poster.jpg",
  },
  {
    id: 5,
    title: "Top Gun: Maverick",
    year: "2022",
    poster: "/top-gun-maverick-movie-poster.jpg",
  },
  {
    id: 6,
    title: "Avatar: The Way of Water",
    year: "2022",
    poster: "/avatar-way-of-water-poster.jpg",
  },
]

const downloads = [
  {
    id: 1,
    name: "Ubuntu 24.04 Desktop ISO",
    progress: 65,
    speed: "2.5 MB/s",
    eta: "5 min",
  },
  {
    id: 2,
    name: "The Matrix Resurrections (2021) 4K",
    progress: 42,
    speed: "8.3 MB/s",
    eta: "12 min",
  },
  {
    id: 3,
    name: "Breaking Bad S05E16 - Finale",
    progress: 88,
    speed: "5.1 MB/s",
    eta: "2 min",
  },
]

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background p-6 md:p-8 flex flex-col gap-6">
        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* Disk Space Gauge */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Disk Space</CardTitle>
              <Hdd className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex items-center justify-center pb-6">
              <ChartContainer config={chartConfig} className="mx-auto aspect-square w-full max-w-[200px]">
                <RadialBarChart
                  data={chartData}
                  startAngle={90}
                  endAngle={90 + (chartData[0].usage / 100) * 360}
                  innerRadius={70}
                  outerRadius={90}
                >
                  <PolarRadiusAxis tick={false} tickLine={false} axisLine={false}>
                    <Label
                      content={({ viewBox }) => {
                        if (viewBox && "cx" in viewBox && "cy" in viewBox) {
                          return (
                            <text x={viewBox.cx} y={viewBox.cy} textAnchor="middle">
                              <tspan
                                x={viewBox.cx}
                                y={(viewBox.cy || 0) - 10}
                                className="fill-foreground text-3xl font-bold"
                              >
                                {chartData[0].usage}%
                              </tspan>
                              <tspan
                                x={viewBox.cx}
                                y={(viewBox.cy || 0) + 15}
                                className="fill-muted-foreground text-sm"
                              >
                                1.2 TB / 4.0 
                              </tspan>
                            </text>
                          )
                        }
                      }}
                    />
                  </PolarRadiusAxis>
                  <RadialBar
                    dataKey="usage"
                    cornerRadius={10}
                    fill="hsl(var(--chart-1))"
                    className="stroke-transparent stroke-2"
                  />
                </RadialBarChart>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Movies Stat Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Movies</CardTitle>
              <Clapperboard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">342</div>
            </CardContent>
          </Card>

          {/* TV Series Stat Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">TV Series</CardTitle>
              <Tv className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">58</div>
            </CardContent>
          </Card>

          {/* Active Downloads Stat Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Downloads</CardTitle>
              <Download className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">3</div>
            </CardContent>
          </Card>
        </div>

        {/* Recently Added Section */}
        <Card>
          <CardHeader>
            <CardTitle>Recently Added Movies</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {recentMovies.map((movie) => (
                <div key={movie.id} className="flex-shrink-0 space-y-2">
                  <div className="relative h-[240px] w-[160px] overflow-hidden rounded-lg bg-muted">
                    <Image
                      src={movie.poster || "/placeholder.svg"}
                      alt={movie.title}
                      fill
                      className="object-cover transition-transform hover:scale-105"
                    />
                  </div>
                  <div className="w-[160px] space-y-1">
                    <p className="text-sm font-medium leading-tight text-foreground line-clamp-2">{movie.title}</p>
                    <p className="text-xs text-muted-foreground">{movie.year}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Active Downloads Section */}
        <Card>
          <CardHeader>
            <CardTitle>Active Downloads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {downloads.map((download) => (
                <div key={download.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground">{download.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {download.speed} - {download.eta}
                    </p>
                  </div>
                  <Progress value={download.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
    </div>
  )
}
